"""Task 4: Real-time weather app using Open-Meteo (no API key required)."""
import tkinter as tk
from tkinter import messagebox
import threading
import requests

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
WEATHER_URL = "https://api.open-meteo.com/v1/forecast"

WEATHER_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog", 51: "Light drizzle", 53: "Moderate drizzle",
    55: "Dense drizzle", 56: "Light freezing drizzle", 57: "Dense freezing drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain", 66: "Light freezing rain",
    67: "Heavy freezing rain", 71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow",
    77: "Snow grains", 80: "Slight rain showers", 81: "Moderate rain showers",
    82: "Violent rain showers", 85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail"
}

def fetch_weather(city):
    """Look up a city, then retrieve its current weather from Open-Meteo."""
    geo_response = requests.get(GEOCODING_URL, params={"name": city, "count": 1, "language": "en", "format": "json"}, timeout=10)
    geo_response.raise_for_status()
    results = geo_response.json().get("results", [])
    if not results:
        raise ValueError(f"No location found for '{city}'. Check the spelling and try again.")
    place = results[0]
    weather_response = requests.get(
        WEATHER_URL,
        params={
            "latitude": place["latitude"], "longitude": place["longitude"],
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m",
            "timezone": "auto"
        },
        timeout=10
    )
    weather_response.raise_for_status()
    current = weather_response.json().get("current")
    if not current:
        raise ValueError("The weather service did not return current conditions.")
    return place, current

class WeatherApp:
    def __init__(self, root):
        self.root = root
        root.title("Weather Information")
        root.geometry("440x390")
        root.minsize(380, 340)
        tk.Label(root, text="Weather Information", font=("Arial", 18, "bold")).pack(pady=(18, 6))
        tk.Label(root, text="Enter a city to get current weather").pack()
        row = tk.Frame(root)
        row.pack(fill="x", padx=22, pady=12)
        self.city_entry = tk.Entry(row, font=("Arial", 12))
        self.city_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.city_entry.insert(0, "Kondotty")
        self.city_entry.bind("<Return>", lambda _event: self.search())
        self.search_button = tk.Button(row, text="Search", command=self.search)
        self.search_button.pack(side="left", padx=(8, 0))
        self.status = tk.Label(root, text="Ready", fg="gray")
        self.status.pack()
        self.result = tk.Label(root, text="Search for a city to see its weather.", font=("Arial", 12),
                               justify="left", anchor="w")
        self.result.pack(fill="both", expand=True, padx=26, pady=18)

    def search(self):
        city = self.city_entry.get().strip()
        if not city:
            messagebox.showwarning("City required", "Please enter a city name.")
            return
        self.search_button.config(state="disabled")
        self.status.config(text="Fetching current weather…")
        threading.Thread(target=self._worker, args=(city,), daemon=True).start()

    def _worker(self, city):
        try:
            place, current = fetch_weather(city)
            details = (
                f"{place['name']}, {place.get('admin1', place.get('country', ''))}\n\n"
                f"Temperature: {current.get('temperature_2m', 'N/A')} °C\n"
                f"Feels like: {current.get('apparent_temperature', 'N/A')} °C\n"
                f"Conditions: {WEATHER_CODES.get(current.get('weather_code'), 'Unknown')}\n"
                f"Humidity: {current.get('relative_humidity_2m', 'N/A')}%\n"
                f"Wind speed: {current.get('wind_speed_10m', 'N/A')} km/h\n"
                f"Precipitation: {current.get('precipitation', 'N/A')} mm"
            )
            self.root.after(0, lambda: self._show_result(details))
        except requests.RequestException as exc:
            error = f"Network/API error: {exc}"
            self.root.after(0, lambda message=error: self._show_error(message))
        except (ValueError, KeyError) as exc:
            error = str(exc)
            self.root.after(0, lambda message=error: self._show_error(message))

    def _show_result(self, details):
        self.result.config(text=details)
        self.status.config(text="Weather updated")
        self.search_button.config(state="normal")

    def _show_error(self, error):
        self.status.config(text="Could not retrieve weather")
        self.search_button.config(state="normal")
        messagebox.showerror("Weather lookup failed", error)

def main():
    root = tk.Tk()
    WeatherApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
