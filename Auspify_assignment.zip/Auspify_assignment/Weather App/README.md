# 🌦️ Weather Information App


## 📌 Project Overview

The Weather Information App allows users to search for a city and view its current weather conditions. It uses Python's Tkinter library to create the graphical interface and the Open-Meteo API to retrieve weather data.

## ✨ Features

- **City Search:** Search for weather information by city name.
- **Real-Time Weather:** Retrieve current weather data through an API.
- **Temperature:** Display the current temperature in Celsius.
- **Feels-Like Temperature:** Show the apparent temperature.
- **Weather Conditions:** Display conditions such as clear sky, cloudy weather, or rain.
- **Humidity:** Display relative humidity.
- **Wind Speed:** Show current wind speed.
- **Precipitation:** Display current precipitation.
- **Error Handling:** Handle invalid city names, network errors, and API failures.
- **User-Friendly Interface:** Simple desktop interface built with Tkinter.

## 🛠️ Technologies Used

- **Python** — Core programming language
- **Tkinter** — Graphical user interface
- **Requests** — HTTP requests to weather services
- **JSON** — Processing API responses
- **Open-Meteo API** — Geocoding and weather data

## 📂 Project Structure

```text
Task-4-Weather-App/
├── task4_weather_app.py
├── requirements.txt
└── README.md
```

## ⚙️ Requirements

- Python 3.10 or newer recommended
- Internet connection
- `requests` Python library
- Tkinter, normally included with Python on Windows

No API key is required for the Open-Meteo services used in this project.

## 🚀 Installation and Setup

### Step 1: Download the project

Download or clone this repository and open the project folder in Command Prompt or a terminal.

### Step 2: Install dependencies

Run:

```bash
python -m pip install -r requirements.txt
```

If you do not have a `requirements.txt` file, install the dependency directly:

```bash
python -m pip install requests
```

### Step 3: Run the application

Execute:

```bash
python task4_weather_app.py
```

The Weather Information App window should open.

## 🖥️ How to Use

1. Launch the application.
2. Enter the name of a city in the search field.
3. Click the **Search** button or press Enter.
4. Wait while the application retrieves the weather information.
5. View the temperature, apparent temperature, weather conditions, humidity, wind speed, and precipitation.

If the city cannot be found or the API request fails, the application displays an appropriate error message.

## 🌐 API Information

This project uses the following Open-Meteo services:

- **Geocoding API:** Finds a city's geographic coordinates from its name.
- **Forecast API:** Retrieves current weather measurements for those coordinates.

The application sends HTTP requests to the API endpoints and processes the returned JSON data.

## 🧪 Testing

The following tests can be performed:

| Test | Expected Result |
|---|---|
| Search for a valid city | Displays current weather information |
| Search for an invalid city | Displays a location-not-found message |
| Submit an empty city field | Requests a city name |
| Disconnect from the internet | Displays a network or API error |
| Search for another city | Displays weather for the newly selected location |

