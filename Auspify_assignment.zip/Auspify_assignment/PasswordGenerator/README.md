# Password Generator

A simple command-line password generator written in Python. It uses Python's standard library to generate random passwords containing letters, numbers, and symbols.

## Features

- Generate one or more passwords in a single run.
- Choose the password length.
- Choose whether to include letters, numbers, and symbols.
- Ensures each selected character type appears at least once.
- Uses Python's `secrets` module for secure random choices.
- Requires no third-party Python packages.

## Requirements

- Python 3.10 or newer is recommended.
- No external packages are required; the program uses Python's standard library.

## Project File

```text
PasswordGenerator/
└── task1_password_generator.py
```

## How to Run

1. Install Python if it is not already installed.
2. Open a terminal in the folder containing `task1_password_generator.py`.
3. Run:

   ```bash
   python task1_password_generator.py
   ```

   On Windows, if `python` is not recognized, try:

   ```bash
   py task1_password_generator.py
   ```

## How to Use

The program asks you for:

1. **Password length** — enter at least 3 characters.
2. **How many passwords?** — enter at least 1.
3. **Include letters?** — enter `Y` or press Enter for yes, or enter `n` for no.
4. **Include numbers?** — enter `Y` or press Enter for yes, or enter `n` for no.
5. **Include symbols?** — enter `Y` or press Enter for yes, or enter `n` for no.

The generated passwords are printed in the terminal.

### Example

```text
=== Password Generator ===
Password length (minimum 3): 12
How many passwords? 2
Include letters? [Y/n]: y
Include numbers? [Y/n]: y
Include symbols? [Y/n]: y
1. <generated-password>
2. <generated-password>
```

The passwords shown when you run the program will be different each time.

## Security Notes

- Prefer long, unique passwords (for example, 16 characters or more) for important accounts.
- Store generated passwords in a reputable password manager rather than in plain-text files.
- Never share passwords or commit real passwords to a public repository.
- This program generates passwords locally; review the code and your environment before using it for sensitive accounts.

## Limitations

- This is a command-line program; it does not currently include a graphical user interface.
- Passwords are printed in the terminal and are not automatically saved to a file.
- The program requires at least one character type to be selected, and the requested length must be sufficient for the selected types.

## License

No license has been specified for this project. Add a license file if you plan to distribute it.
