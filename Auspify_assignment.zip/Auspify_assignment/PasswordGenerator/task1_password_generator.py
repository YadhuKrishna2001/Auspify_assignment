"""Task 1: Secure password generator (Python standard library only)."""
import secrets
import string

LETTERS = string.ascii_letters
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/"

def generate_password(length: int, use_letters=True, use_digits=True, use_symbols=True) -> str:
    """Generate a password, ensuring each selected character class is represented."""
    pools = []
    if use_letters:
        pools.append(LETTERS)
    if use_digits:
        pools.append(DIGITS)
    if use_symbols:
        pools.append(SYMBOLS)
    if not pools:
        raise ValueError("Select at least one character type.")
    if length < len(pools):
        raise ValueError(f"Length must be at least {len(pools)} for the selected character types.")

    # Guarantee one character from each selected pool, then fill and shuffle securely.
    chars = [secrets.choice(pool) for pool in pools]
    combined = "".join(pools)
    chars.extend(secrets.choice(combined) for _ in range(length - len(chars)))
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)

def main():
    print("=== Password Generator ===")
    while True:
        try:
            length = int(input("Password length (minimum 3): ").strip())
            if length < 3:
                print("Please enter a length of at least 3.")
                continue
            count = int(input("How many passwords? ").strip())
            if count < 1:
                print("Please enter at least 1 password.")
                continue
            include_letters = input("Include letters? [Y/n]: ").strip().lower() not in ("n", "no")
            include_digits = input("Include numbers? [Y/n]: ").strip().lower() not in ("n", "no")
            include_symbols = input("Include symbols? [Y/n]: ").strip().lower() not in ("n", "no")
            for i in range(count):
                print(f"{i + 1}. {generate_password(length, include_letters, include_digits, include_symbols)}")
            break
        except ValueError as exc:
            print(f"Invalid input: {exc}")

if __name__ == "__main__":
    main()
