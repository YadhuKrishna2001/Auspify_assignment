"""Task 2: Persistent To-Do List GUI using Tkinter and JSON."""
import json
import tkinter as tk
from tkinter import messagebox
from pathlib import Path

DATA_FILE = Path(__file__).with_name("tasks.json")

def load_tasks():
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return []

def save_tasks(tasks):
    DATA_FILE.write_text(json.dumps(tasks, indent=2, ensure_ascii=False), encoding="utf-8")

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")
        self.root.geometry("520x440")
        self.root.minsize(420, 340)
        self.tasks = load_tasks()

        tk.Label(root, text="My To-Do List", font=("Arial", 18, "bold")).pack(pady=(14, 8))
        entry_row = tk.Frame(root)
        entry_row.pack(fill="x", padx=16)
        self.entry = tk.Entry(entry_row, font=("Arial", 11))
        self.entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.entry.bind("<Return>", lambda _event: self.add_task())
        tk.Button(entry_row, text="Add task", command=self.add_task).pack(side="left", padx=(8, 0))

        self.listbox = tk.Listbox(root, font=("Arial", 11), selectmode=tk.SINGLE, activestyle="dotbox")
        self.listbox.pack(fill="both", expand=True, padx=16, pady=12)
        controls = tk.Frame(root)
        controls.pack(pady=(0, 8))
        tk.Button(controls, text="Mark complete / undo", command=self.toggle_task).pack(side="left", padx=4)
        tk.Button(controls, text="Delete selected", command=self.delete_task).pack(side="left", padx=4)
        tk.Button(controls, text="Save", command=self.save).pack(side="left", padx=4)
        self.status = tk.Label(root, text="", fg="gray")
        self.status.pack(pady=(0, 10))
        self.refresh()

    def refresh(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            mark = "✓" if task.get("completed") else "○"
            self.listbox.insert(tk.END, f"{mark}  {task.get('text', '')}")
        self.status.config(text=f"{len(self.tasks)} task(s) · saved to {DATA_FILE.name}")

    def add_task(self):
        text = self.entry.get().strip()
        if not text:
            messagebox.showwarning("Missing task", "Enter a task before adding it.")
            return
        self.tasks.append({"text": text, "completed": False})
        self.entry.delete(0, tk.END)
        self.save(show_message=False)
        self.refresh()

    def selected_index(self):
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showinfo("Select a task", "Please select a task first.")
            return None
        return selection[0]

    def toggle_task(self):
        index = self.selected_index()
        if index is None:
            return
        self.tasks[index]["completed"] = not self.tasks[index].get("completed", False)
        self.save(show_message=False)
        self.refresh()
        self.listbox.selection_set(index)

    def delete_task(self):
        index = self.selected_index()
        if index is None:
            return
        del self.tasks[index]
        self.save(show_message=False)
        self.refresh()

    def save(self, show_message=True):
        try:
            save_tasks(self.tasks)
            self.status.config(text=f"Saved {len(self.tasks)} task(s) to {DATA_FILE.name}")
            if show_message:
                messagebox.showinfo("Saved", "Your tasks have been saved.")
        except OSError as exc:
            messagebox.showerror("Save error", f"Could not save tasks:\n{exc}")

def main():
    root = tk.Tk()
    TodoApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
