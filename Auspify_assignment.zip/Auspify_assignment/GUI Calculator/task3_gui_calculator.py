"""Task 3: Tkinter calculator with arithmetic and input validation."""
import tkinter as tk
from tkinter import messagebox
import ast
import operator

# Evaluate only numeric constants and explicitly allowed arithmetic operators; never use eval().
_ALLOWED = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}

def safe_calculate(expression: str):
    """Calculate a basic arithmetic expression safely."""
    tree = ast.parse(expression, mode="eval")
    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 8:
                raise ValueError("Exponent is too large.")
            return _ALLOWED[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED:
            return _ALLOWED[type(node.op)](visit(node.operand))
        raise ValueError("Only numbers and basic arithmetic operators are allowed.")
    result = visit(tree)
    if isinstance(result, complex):
        raise ValueError("Complex results are not supported.")
    return result

class Calculator:
    def __init__(self, root):
        self.root = root
        root.title("Python Calculator")
        root.geometry("360x470")
        root.resizable(False, False)
        self.expression = tk.StringVar()
        tk.Label(root, text="Calculator", font=("Arial", 18, "bold")).pack(pady=(14, 8))
        self.display = tk.Entry(root, textvariable=self.expression, font=("Arial", 20),
                                justify="right", state="readonly", readonlybackground="white")
        self.display.pack(fill="x", padx=16, ipady=10)
        grid = tk.Frame(root)
        grid.pack(expand=True, fill="both", padx=12, pady=12)
        buttons = [
            ("C", "⌫", "(", ")"),
            ("7", "8", "9", "/"),
            ("4", "5", "6", "*"),
            ("1", "2", "3", "-"),
            ("0", ".", "%", "+"),
            ("^", "=",),
        ]
        for r, row in enumerate(buttons):
            for c, label in enumerate(row):
                btn = tk.Button(grid, text=label, font=("Arial", 14), command=lambda x=label: self.press(x))
                btn.grid(row=r, column=c, sticky="nsew", padx=3, pady=3, columnspan=2 if label == "=" else 1)
        for r in range(len(buttons)):
            grid.rowconfigure(r, weight=1)
        for c in range(4):
            grid.columnconfigure(c, weight=1)

    def press(self, key):
        current = self.expression.get()
        if key == "C":
            self.expression.set("")
        elif key == "⌫":
            self.expression.set(current[:-1])
        elif key == "=":
            try:
                expr = current.replace("^", "**")
                result = safe_calculate(expr)
                self.expression.set(str(result))
            except (SyntaxError, ZeroDivisionError, ValueError, OverflowError) as exc:
                messagebox.showerror("Calculation error", str(exc) or "Invalid expression.")
        else:
            self.expression.set(current + key)

def main():
    root = tk.Tk()
    Calculator(root)
    root.mainloop()

if __name__ == "__main__":
    main()
